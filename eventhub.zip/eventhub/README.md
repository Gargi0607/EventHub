# EventHub

A five page event management website. Home, Events, Register and Dashboard are built with
React 18. The Feedback page is built with AngularJS 1.8.

## Running it

```bash
npm install
npm run dev
```

Then open the URL Vite prints, usually http://localhost:5173

To build a production copy:

```bash
npm run build
npm run preview
```

## Project files

```
src/
  main.jsx        picks the page from the browser address
  data.js         the event list and the browser storage helpers
  Navbar.jsx      navigation menu used on every page
  Footer.jsx      footer used on every page
  Home.jsx        landing page
  Events.jsx      event cards, filters and booking
  EventCard.jsx   one event card, reused by Events
  Register.jsx    registration form with validation
  Dashboard.jsx   the two tables
  index.css       all the styling
public/
  feedback.html   the AngularJS page
  angular.min.js  AngularJS 1.8, kept locally so it works offline
  angular-page.css
```

## What each page does

**Home** — the landing page. Shows how many events, cities and seats are available and
lists the three events closest to selling out.

**Events** — event cards with category filter chips and a search box. Booking a seat
lowers the seat count everywhere in the site.

**Register** — a validated registration form. Checks name, email, phone, age, ticket count
against the remaining seats, and the terms checkbox. Nothing is saved until every rule passes.

**Dashboard** — a sortable table of the event inventory and a table of everyone who has
registered, with totals in the footer rows.

**Feedback** — an AngularJS page with a live preview that updates as you type, a list of
submitted feedback with search and sort, and star ratings.

## Notes

- The events and registrations are kept in the browser's localStorage. To start over, open
  the browser console and run `localStorage.clear()`, then reload.

See `TOPICS.md` for a table mapping every syllabus topic to the exact file and function.
