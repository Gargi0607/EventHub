# EventHub — topic coverage map

Event management website. Four pages are built with React 18, the fifth with AngularJS 1.8.
There is no router library: the page is chosen in `main.jsx` with an if / else if / else
chain on `window.location.pathname`.

| # | Topic | File | Where to look |
|---|-------|------|---------------|
| 1 | `console.log` | `src/Home.jsx`, `src/Events.jsx`, `src/Dashboard.jsx`, `src/Register.jsx` | Home logs the event totals on load; Events logs each filter change and booking; Register logs failed validation and each new attendee; Dashboard logs each sort and cancellation. |
| 2 | `alert` | `src/Register.jsx` | Alert on failed validation and on confirmed registration. `window.confirm` is used in `EventCard.jsx` before removing an event. |
| 3 | Decision making | `src/EventCard.jsx` | `if / else if / else` picks the Sold out / Filling fast / Open status. Also `Dashboard.jsx` (status badges), `Events.jsx` (filter logic), `data.js` (saved copy or default copy), `Navbar.jsx` (active link). |
| 4 | Loops | `src/Home.jsx`, `src/Events.jsx`, `src/Dashboard.jsx` | Plain `for` loops total the seats, count the sold out events, build the category list, filter the cards and add up the revenue. A `for` loop in `feedback.html` builds the star rating. `.map()` renders every card, option and table row. |
| 5 | Arrays | `src/data.js` | `defaultEvents` is the master array. `push`, `indexOf`, `slice`, `sort` and `map` are used across Home, Events, Register and Dashboard. |
| 6 | Handling data with React | `src/data.js` | Every page loads separately in the browser, so the event list and the registrations are stored with `localStorage` and read back through `getEvents()` and `getRegistrations()`. Each page then holds its own copy in `useState`. |
| 7 | Creating a table with React | `src/Dashboard.jsx` | Two tables. `<thead>` is written by hand, every `<tr>` in `<tbody>` comes from `.map()`. Click a column heading to sort. `<tfoot>` shows computed totals. |
| 8 | Form validation with React | `src/Register.jsx` | `validate()` is a list of `if / else if` rules checking name, email, phone, age, ticket count against remaining seats, and the terms checkbox. Each field has its own `useState`, and the error messages appear under the fields when the form is submitted. |
| 9 | Passing function arguments into React | `src/Events.jsx` → `src/EventCard.jsx` | `onBook` and `onRemove` are defined in `Events` and handed to `EventCard` as props. `EventCard` calls `onBook(event.id)` — the id is the argument sent back to the parent. |
| 10 | Styling React with CSS | `src/index.css` | One external stylesheet imported in `main.jsx`. Class names through `className`, conditional classes (`chip chip-active`, `status low`), CSS grid, flexbox and media queries. |
| 11 | AngularJS | `public/feedback.html` | `ng-app`, `ng-controller`, `ng-model` two-way binding, `ng-repeat`, `ng-show`, `ng-if`, `ng-class`, `ng-click`, `ng-options`, `ng-submit`, the `filter`, `orderBy` and `number` filters, `$timeout` injection, and AngularJS form state (`$invalid`, `$touched`). |

## Pages

| Page | Address | Component | Framework |
|------|---------|-----------|-----------|
| Home | `/` | `src/Home.jsx` | React |
| Events | `/events` | `src/Events.jsx` | React |
| Register | `/register` | `src/Register.jsx` | React |
| Dashboard | `/dashboard` | `src/Dashboard.jsx` | React |
| Feedback | `/feedback.html` | — | AngularJS 1.8 |

## How the pages are selected

`main.jsx` reads `window.location.pathname` and picks the component:

```
if      (path === "/events")    page = <Events />;
else if (path === "/register")  page = <Register />;
else if (path === "/dashboard") page = <Dashboard />;
else                            page = <Home />;
```

Because every link is a plain `<a href>`, clicking one reloads the page and `main.jsx`
runs again. That is also why the data lives in `localStorage` rather than in React state
alone — otherwise the seat counts and the attendee list would reset on every click.

## Why the AngularJS page is a separate HTML file

React and AngularJS both want to own the DOM and they start up in different ways, so
running AngularJS inside a React page means fighting both frameworks. Keeping it as a
standalone page in `public/` is the normal way to combine them. AngularJS is served from
`public/angular.min.js` rather than a CDN, so the page also works with no internet.
