import React from 'react';
import Navbar from './Navbar.jsx';
import Footer from './Footer.jsx';
import { getEvents } from './data.js';

function Home() {
  // The event list is read from the shared data file
  const events = getEvents();

  // ---------- LOOP: count the total seats and the sold out events ----------
  let totalSeats = 0;
  let soldOut = 0;

  for (let i = 0; i < events.length; i++) {
    totalSeats = totalSeats + events[i].seats;

    if (events[i].seats <= 0) {
      soldOut = soldOut + 1;
    }
  }

  // ---------- ARRAY + LOOP: collect the city names without repeating any ----------
  const cities = [];

  for (let i = 0; i < events.length; i++) {
    // indexOf returns -1 when the city is not in the array yet
    if (cities.indexOf(events[i].venue) === -1) {
      cities.push(events[i].venue);
    }
  }

  // The same idea again, this time for the categories
  const categories = [];

  for (let i = 0; i < events.length; i++) {
    if (categories.indexOf(events[i].category) === -1) {
      categories.push(events[i].category);
    }
  }

  // ---------- The three events with the fewest seats left ----------
  const available = [];

  for (let i = 0; i < events.length; i++) {
    if (events[i].seats > 0) {
      available.push(events[i]);
    }
  }

  // sort puts the smallest seat count first
  available.sort(function (a, b) {
    return a.seats - b.seats;
  });

  const closingSoon = available.slice(0, 3);

  console.log('[Home] events:', events.length, '| seats open:', totalSeats, '| cities:', cities);

  return (
    <div className="app">
      <Navbar />

      <header className="hero">
        <h1>Discover and book events near you</h1>
        <p>Browse what is coming up, grab a seat, and keep track of every booking.</p>

        <div className="hero-actions">
          <a href="/events" className="btn-accent hero-btn">Browse events</a>
          <a href="/register" className="btn-ghost">Register now</a>
        </div>

        <div className="hero-stats">
          <div><b>{events.length}</b>events listed</div>
          <div><b>{cities.length}</b>cities</div>
          <div><b>{totalSeats}</b>seats open</div>
        </div>
      </header>

      <div className="stat-strip">
        <div><b>{categories.length}</b><span>Categories to choose from</span></div>
        <div><b>{soldOut}</b><span>Sold out this month</span></div>
        <div><b>Free</b><span>Entry on selected meetups</span></div>
        <div><b>1 min</b><span>Average time to register</span></div>
      </div>

      <section className="section">
        <h2>Closing soon</h2>
        <p className="lead">The events with the fewest seats left. Book these first.</p>

        <div className="cards">
          {/* LOOP: one card per event */}
          {closingSoon.map((event) => (
            <a key={event.id} href="/events" className="mini-card">
              <div className="mini-card-head">
                <h3>{event.name}</h3>
                <span className="tag">{event.category}</span>
              </div>
              <p className="venue">{event.venue}, {event.date}</p>
              {/* DECISION MAKING: the urgency line depends on the seat count */}
              <p className={seatClass(event.seats)}>{seatText(event.seats)}</p>
            </a>
          ))}
        </div>

        {/* DECISION MAKING: conditional rendering when everything is booked out */}
        {closingSoon.length === 0 && (
          <p className="empty-state">Every listed event is sold out. Check back next week.</p>
        )}
      </section>

      <section className="section">
        <h2>How it works</h2>
        <div className="info-grid">
          <div className="info-card">
            <h3>Browse</h3>
            <p>Filter by category or search by name. Seat counts update the moment someone books.</p>
          </div>
          <div className="info-card">
            <h3>Register</h3>
            <p>One short form. It checks your details and refuses to book more seats than are left.</p>
          </div>
          <div className="info-card">
            <h3>Track</h3>
            <p>The dashboard lists every event and every attendee, and adds up the totals for you.</p>
          </div>
        </div>
        <p className="lead" style={{ marginTop: '20px' }}>
          <a href="/dashboard" className="card-link btn-primary">Open the dashboard</a>
        </p>
      </section>

      <Footer />
    </div>
  );
}

// DECISION MAKING: these two small functions decide what the seat line says
function seatClass(seats) {
  if (seats < 10) {
    return 'status low';
  }
  return 'status open';
}

function seatText(seats) {
  if (seats < 10) {
    return 'Only ' + seats + ' seats left';
  }
  return seats + ' seats available';
}

export default Home;
