import React, { useState } from 'react';
import Navbar from './Navbar.jsx';
import Footer from './Footer.jsx';
import EventCard from './EventCard.jsx';
import { getEvents, saveEvents } from './data.js';

function Events() {
  const [events, setEvents] = useState(getEvents());
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');

  // Shows a short message at the top of the page and clears it after a moment
  const flash = (text) => {
    setNotice(text);
    setTimeout(() => setNotice(''), 2500);
  };

  // ---------- These two functions are PASSED AS ARGUMENTS to EventCard ----------
  const onBook = (eventId) => {
    const updated = [];
    let booked = null;

    // LOOP: copy every event, and lower the seats of the one that was booked
    for (let i = 0; i < events.length; i++) {
      const event = events[i];

      if (event.id === eventId) {
        booked = event;
        updated.push({
          id: event.id,
          name: event.name,
          category: event.category,
          venue: event.venue,
          date: event.date,
          price: event.price,
          seats: event.seats - 1,
        });
      } else {
        updated.push(event);
      }
    }

    setEvents(updated);
    saveEvents(updated);
    console.log('[bookSeat] seat booked for:', booked.name, '| seats left:', booked.seats - 1);
    flash('Booked a seat for ' + booked.name);
  };

  const onRemove = (eventId) => {
    const updated = [];

    // LOOP: keep every event except the one that was removed
    for (let i = 0; i < events.length; i++) {
      if (events[i].id !== eventId) {
        updated.push(events[i]);
      }
    }

    setEvents(updated);
    saveEvents(updated);
    console.log('[removeEvent] removed event id:', eventId);
    flash('Event removed from the list');
  };

  // ---------- ARRAY + LOOP: build the category list from the data itself ----------
  const categories = ['All'];

  for (let i = 0; i < events.length; i++) {
    if (categories.indexOf(events[i].category) === -1) {
      categories.push(events[i].category);
    }
  }

  // ---------- DECISION MAKING: keep only the events that match the filters ----------
  const visible = [];
  const typed = search.toLowerCase();

  for (let i = 0; i < events.length; i++) {
    const event = events[i];

    // does it match the category button that is selected?
    let matchesCategory = false;
    if (category === 'All') {
      matchesCategory = true;
    } else if (event.category === category) {
      matchesCategory = true;
    }

    // does the name contain what was typed in the search box?
    let matchesSearch = false;
    if (event.name.toLowerCase().indexOf(typed) !== -1) {
      matchesSearch = true;
    }

    if (matchesCategory && matchesSearch) {
      visible.push(event);
    }
  }

  // ---------- LOOP: total the seats of the events on screen ----------
  let seatsOnScreen = 0;

  for (let i = 0; i < visible.length; i++) {
    seatsOnScreen = seatsOnScreen + visible[i].seats;
  }

  const handleFilterClick = (value) => {
    setCategory(value);
    console.log('[filter] category set to:', value);
  };

  // DECISION MAKING: the selected button gets an extra class
  function chipClass(name) {
    if (name === category) {
      return 'chip chip-active';
    }
    return 'chip';
  }

  return (
    <div className="app">
      <Navbar />
      {notice && <div className="toast">{notice}</div>}

      <section className="section">
      <h2>Upcoming events</h2>

      <div className="filter-bar">
        {/* LOOP: map turns the categories array into buttons */}
        {categories.map((cat) => (
          <button
            key={cat}
            className={chipClass(cat)}
            onClick={() => handleFilterClick(cat)}
          >
            {cat}
          </button>
        ))}

        <input
          className="search-input"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by event name"
        />
      </div>

      <p className="lead">
        Showing {visible.length} of {events.length} events · {seatsOnScreen} seats available
      </p>

      <div className="cards">
        {/* LOOP: one EventCard per event.
            onBook and onRemove are FUNCTIONS PASSED AS ARGUMENTS into the child. */}
        {visible.map((event) => (
          <EventCard
            key={event.id}
            event={event}
            onBook={onBook}
            onRemove={onRemove}
          />
        ))}
      </div>

      {/* DECISION MAKING: conditional rendering for the empty state */}
      {visible.length === 0 && (
        <p className="empty-state">
          No events match that filter. Clear the search box or pick another category.
        </p>
      )}
      </section>

      <Footer />
    </div>
  );
}

export default Events;
