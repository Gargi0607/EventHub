import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import Home from "./Home.jsx";
import Events from "./Events.jsx";
import Register from "./Register.jsx";
import Dashboard from "./Dashboard.jsx";

// The page to show is decided from the address in the browser's address bar.
// window.location.pathname gives the part after the domain name, for example
// "/events". A simple if / else if / else chain picks the matching component.

const path = window.location.pathname;
let page;

if (path === "/events") {
  page = <Events />;
}
else if (path === "/register") {
  page = <Register />;
}
else if (path === "/dashboard") {
  page = <Dashboard />;
}
else {
  page = <Home />;
}

ReactDOM.createRoot(
  document.getElementById("root")
).render(page);
