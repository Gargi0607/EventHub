import React from "react";

// The footer is a separate component so the same line appears on every page.
function Footer() {
  return (
    <footer className="footer">
      EventHub · 12 MG Road, Mumbai · hello@eventhub.com · +91 22 4000 1200
    </footer>
  );
}

export default Footer;
