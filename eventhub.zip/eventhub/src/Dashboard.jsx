import React, { useState } from 'react';
import Navbar from './Navbar.jsx';
import Footer from './Footer.jsx';
import { getEvents, getRegistrations, saveRegistrations } from './data.js';

function Dashboard() {
  const events = getEvents();

  const [registrations, setRegistrations] = useState(getRegistrations());
  const [sortKey, setSortKey] = useState('name');
  const [ascending, setAscending] = useState(true);

  // Clicking the same heading twice flips the direction
  const changeSort = (key) => {
    if (key === sortKey) {
      setAscending(!ascending);
    } else {
      setSortKey(key);
      setAscending(true);
    }
    console.log('[sort] column:', key);
  };

  // Removes one attendee and stores the shorter list back in the browser
  const onCancel = (id) => {
    const updated = [];

    for (let i = 0; i < registrations.length; i++) {
      if (registrations[i].id !== id) {
        updated.push(registrations[i]);
      }
    }

    setRegistrations(updated);
    saveRegistrations(updated);
    console.log('[cancelRegistration] removed id:', id);
  };

  // ---------- ARRAY: sort a copy so the original order is never changed ----------
  const sortedEvents = events.slice();

  sortedEvents.sort(function (a, b) {
    const x = a[sortKey];
    const y = b[sortKey];
    let result = 0;

    if (x < y) {
      result = -1;
    } else if (x > y) {
      result = 1;
    }

    // clicking twice sorts the other way round
    if (ascending === false) {
      result = -result;
    }

    return result;
  });

  // The little triangle drawn next to the column that is being sorted
  function arrow(key) {
    if (key !== sortKey) {
      return '';
    }
    if (ascending) {
      return ' \u25B2';
    }
    return ' \u25BC';
  }

  // ---------- LOOP: totals for the event table ----------
  let totalSeats = 0;
  let soldOutCount = 0;

  for (let i = 0; i < events.length; i++) {
    totalSeats = totalSeats + events[i].seats;

    if (events[i].seats <= 0) {
      soldOutCount = soldOutCount + 1;
    }
  }

  // ---------- LOOP: totals for the attendee table ----------
  let totalTickets = 0;
  let revenue = 0;

  for (let i = 0; i < registrations.length; i++) {
    const booking = registrations[i];
    totalTickets = totalTickets + Number(booking.tickets);

    // find the event so we know the price of one ticket
    for (let j = 0; j < events.length; j++) {
      if (events[j].name === booking.event) {
        revenue = revenue + events[j].price * Number(booking.tickets);
      }
    }
  }

  return (
    <div className="app">
      <Navbar />

      <section className="section">
      <h2>Dashboard</h2>

      <div className="stat-row">
        <div className="stat"><b>{events.length}</b><span>Events</span></div>
        <div className="stat"><b>{totalSeats}</b><span>Seats open</span></div>
        <div className="stat"><b>{soldOutCount}</b><span>Sold out</span></div>
        <div className="stat"><b>{registrations.length}</b><span>Registrations</span></div>
        <div className="stat"><b>Rs {revenue}</b><span>Revenue</span></div>
      </div>

      <h3>Event inventory</h3>
      <p className="lead">Click any column heading to sort the table.</p>

      {/* ---------- CREATING A TABLE WITH REACT ----------
          The <thead> is written by hand; every <tr> in <tbody> is produced
          by mapping over the sorted array. */}
      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th onClick={() => changeSort('name')}>Event{arrow('name')}</th>
              <th onClick={() => changeSort('category')}>Category{arrow('category')}</th>
              <th onClick={() => changeSort('venue')}>Venue{arrow('venue')}</th>
              <th onClick={() => changeSort('date')}>Date{arrow('date')}</th>
              <th onClick={() => changeSort('price')}>Price{arrow('price')}</th>
              <th onClick={() => changeSort('seats')}>Seats{arrow('seats')}</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {sortedEvents.map((ev) => (
              <tr key={ev.id} className={rowClass(ev.seats)}>
                <td>{ev.name}</td>
                <td><span className="tag">{ev.category}</span></td>
                <td>{ev.venue}</td>
                <td>{ev.date}</td>
                <td>{priceText(ev.price)}</td>
                <td>{ev.seats}</td>
                {/* DECISION MAKING inside a table cell */}
                <td>{statusBadge(ev.seats)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan="5">Total across {events.length} events</td>
              <td>{totalSeats}</td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <h3>Registered attendees</h3>

      {/* DECISION MAKING: show the table only when there is data */}
      {registrations.length === 0 ? (
        <p className="empty-state">
          No registrations yet. Fill in the form on the Register page and the attendee appears here.
        </p>
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Age</th>
                <th>Event</th>
                <th>Tickets</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {registrations.map((r, index) => (
                <tr key={r.id}>
                  <td>{index + 1}</td>
                  <td>{r.name}</td>
                  <td>{r.email}</td>
                  <td>{r.phone}</td>
                  <td>{r.age}</td>
                  <td>{r.event}</td>
                  <td>{r.tickets}</td>
                  <td>
                    {/* onCancel is called with the id of the row that was clicked */}
                    <button className="btn-link" onClick={() => onCancel(r.id)}>Cancel</button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="6">Total tickets booked</td>
                <td>{totalTickets}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
      </section>

      <Footer />
    </div>
  );
}

// ---------- Small helper functions, so the table cells stay easy to read ----------

function rowClass(seats) {
  if (seats <= 0) {
    return 'row-muted';
  }
  return '';
}

function priceText(price) {
  if (price === 0) {
    return 'Free';
  }
  return 'Rs ' + price;
}

function statusBadge(seats) {
  if (seats <= 0) {
    return <span className="badge badge-red">Sold out</span>;
  } else if (seats < 10) {
    return <span className="badge badge-amber">Filling fast</span>;
  } else {
    return <span className="badge badge-green">Open</span>;
  }
}

export default Dashboard;
