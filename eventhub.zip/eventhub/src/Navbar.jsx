import React from "react";

// The navigation bar is written once as a component and reused on every page.
// The links are plain <a> tags, so clicking one loads that page in the browser
// and main.jsx decides which component to show.

function Navbar() {
  const path = window.location.pathname;

  // DECISION MAKING: the link for the page you are on gets the "active" class
  function linkClass(target) {
    if (path === target) {
      return "active";
    }
    return "";
  }

  return (
    <nav className="navbar">
      <span className="brand">EventHub</span>
      <div className="nav-links">
        <a href="/" className={linkClass("/")}>Home</a>
        <a href="/events" className={linkClass("/events")}>Events</a>
        <a href="/register" className={linkClass("/register")}>Register</a>
        <a href="/dashboard" className={linkClass("/dashboard")}>Dashboard</a>
        <a href="/feedback.html" className={linkClass("/feedback.html")}>Feedback</a>
      </div>
    </nav>
  );
}

export default Navbar;
