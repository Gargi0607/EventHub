import React from 'react';

// PASSING FUNCTION ARGUMENTS INTO A REACT PROGRAM
// This component receives three props: one object (event) and two functions
// (onBook, onRemove). It never owns any data - it only calls the functions
// it was handed, with the argument the parent needs.
function EventCard({ event, onBook, onRemove }) {
  // DECISION MAKING: work out the status before rendering
  let statusClass;
  let statusText;

  if (event.seats <= 0) {
    statusClass = 'status full';
    statusText = 'Sold out';
  } else if (event.seats < 10) {
    statusClass = 'status low';
    statusText = 'Only ' + event.seats + ' seats left';
  } else {
    statusClass = 'status open';
    statusText = event.seats + ' seats available';
  }

  const handleBookClick = () => {
    // The event id is the ARGUMENT passed back up to App.jsx
    onBook(event.id);
  };

  const handleRemoveClick = () => {
    const sure = window.confirm('Remove "' + event.name + '" from the list?');
    if (sure) {
      onRemove(event.id);
    }
  };

  return (
    <article className="event-card">
      <div className="event-card-header">
        <h3>{event.name}</h3>
        <span className="tag">{event.category}</span>
      </div>

      <p className="venue">{event.venue}, {event.date}</p>
      <p className="price">{event.price === 0 ? 'Free entry' : 'Rs ' + event.price}</p>
      <p className={statusClass}>{statusText}</p>

      <div className="event-card-actions">
        <button className="btn-primary" disabled={event.seats <= 0} onClick={handleBookClick}>
          {event.seats <= 0 ? 'Unavailable' : 'Book seat'}
        </button>
        <button className="btn-secondary" onClick={handleRemoveClick}>Remove</button>
      </div>
    </article>
  );
}

export default EventCard;
