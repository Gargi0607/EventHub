// ---------- ARRAY: the master list of event objects ----------
// Every page reads this same array, so the whole site shows the same data.
const defaultEvents = [
  { id: 1, name: 'Tech Summit', category: 'Tech',
    venue: 'Mumbai', date: '15 Oct', price: 499, seats: 120 },

  { id: 2, name: 'Music Fest', category: 'Music',
    venue: 'Pune', date: '20 Oct', price: 899, seats: 300 },

  { id: 3, name: 'Startup Meetup', category: 'Business',
    venue: 'Delhi', date: '25 Oct', price: 0, seats: 6 },

  { id: 4, name: 'Art Expo', category: 'Art',
    venue: 'Bengaluru', date: '2 Nov', price: 250, seats: 45 },

  { id: 5, name: 'Code Marathon', category: 'Tech',
    venue: 'Mumbai', date: '9 Nov', price: 150, seats: 0 },
];

const EVENTS_KEY = 'eventhub_events';
const REGISTRATIONS_KEY = 'eventhub_registrations';

// Each page of this website loads separately in the browser, so React state is
// lost whenever the user moves to another page. The data is therefore stored in
// the browser using localStorage. Without this the seat counts and the list of
// registered attendees would reset on every page change.

export function getEvents() {
  const saved = localStorage.getItem(EVENTS_KEY);

  // DECISION MAKING: use the saved copy if there is one, otherwise start fresh
  if (saved) {
    return JSON.parse(saved);
  }
  return defaultEvents;
}

export function saveEvents(list) {
  localStorage.setItem(EVENTS_KEY, JSON.stringify(list));
}

export function getRegistrations() {
  const saved = localStorage.getItem(REGISTRATIONS_KEY);

  if (saved) {
    return JSON.parse(saved);
  }
  return [];
}

export function saveRegistrations(list) {
  localStorage.setItem(REGISTRATIONS_KEY, JSON.stringify(list));
}
