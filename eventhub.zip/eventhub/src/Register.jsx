import React, { useState } from 'react';
import Navbar from './Navbar.jsx';
import Footer from './Footer.jsx';
import { getEvents, getRegistrations, saveRegistrations } from './data.js';

function Register() {
  const events = getEvents();

  // One piece of state per field. Each input updates its own variable.
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [eventName, setEventName] = useState(events[0] ? events[0].name : '');
  const [tickets, setTickets] = useState('1');
  const [terms, setTerms] = useState(false);

  // The messages to show under the fields. Empty when everything is correct.
  const [errors, setErrors] = useState({});

  // ---------- FORM VALIDATION ----------
  // Every rule is an if statement that adds a message to the errors object.
  function validate() {
    const found = {};

    if (name.trim() === '') {
      found.name = 'Name is required';
    } else if (name.trim().length < 3) {
      found.name = 'Name must be at least 3 characters';
    }

    if (email.trim() === '') {
      found.email = 'Email is required';
    } else if (email.indexOf('@') === -1) {
      found.email = 'Email must contain the @ sign';
    } else if (email.indexOf('.') === -1) {
      found.email = 'Enter a valid email like name@site.com';
    }

    if (phone.trim() === '') {
      found.phone = 'Phone number is required';
    } else if (phone.length !== 10) {
      found.phone = 'Phone number must be exactly 10 digits';
    } else if (isNaN(Number(phone))) {
      found.phone = 'Phone number can only contain digits';
    }

    const ageNumber = Number(age);
    if (age === '') {
      found.age = 'Age is required';
    } else if (ageNumber < 16 || ageNumber > 100) {
      found.age = 'Age must be between 16 and 100';
    }

    // LOOP: find the event that was chosen in the dropdown
    let chosen = null;

    for (let i = 0; i < events.length; i++) {
      if (events[i].name === eventName) {
        chosen = events[i];
      }
    }

    // Cross check: you cannot book more tickets than the seats that are left
    if (chosen === null) {
      found.event = 'Select an event';
    } else if (chosen.seats <= 0) {
      found.event = 'That event is sold out, pick another';
    } else if (Number(tickets) > chosen.seats) {
      found.tickets = 'Only ' + chosen.seats + ' seats left for ' + chosen.name;
    }

    if (terms === false) {
      found.terms = 'You must accept the event rules';
    }

    return found;
  }

  function clearForm() {
    setName('');
    setEmail('');
    setPhone('');
    setAge('');
    setEventName(events[0] ? events[0].name : '');
    setTickets('1');
    setTerms(false);
    setErrors({});
  }

  const handleSubmit = (e) => {
    e.preventDefault();

    const found = validate();
    setErrors(found);

    const problems = Object.keys(found).length;

    // DECISION MAKING on the result of validation
    if (problems > 0) {
      console.log('[validation failed]', found);
      alert('Please fix ' + problems + ' problem(s) before submitting.');
      return;
    }

    // Save the attendee so the Dashboard page can show them in its table
    const record = {
      id: Date.now(),
      name: name,
      email: email,
      phone: phone,
      age: age,
      event: eventName,
      tickets: tickets,
    };

    const saved = getRegistrations();
    saved.push(record);
    saveRegistrations(saved);
    console.log('[addRegistration] new attendee:', record);

    alert('Registration confirmed for ' + name + '.\nEvent: ' + eventName);
    clearForm();
  };

  // DECISION MAKING: a field with an error gets a red box around it
  function boxClass(message) {
    if (message) {
      return 'invalid';
    }
    return '';
  }

  return (
    <div className="app">
      <Navbar />

      <section className="section">
      <h2>Register for an event</h2>
      <p className="lead">
        Every field is checked in React before anything is saved. Try submitting an empty form to see it work.
      </p>

      <form className="register-form" onSubmit={handleSubmit} noValidate>
        <label>
          Full name
          <input
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={boxClass(errors.name)}
            placeholder="Enter your full name"
          />
          {errors.name && <span className="error">{errors.name}</span>}
        </label>

        <label>
          Email
          <input
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={boxClass(errors.email)}
            placeholder="Enter your email address"
          />
          {errors.email && <span className="error">{errors.email}</span>}
        </label>

        <div className="form-row">
          <label>
            Phone
            <input
              name="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className={boxClass(errors.phone)}
              placeholder="10 digit mobile number"
            />
            {errors.phone && <span className="error">{errors.phone}</span>}
          </label>

          <label>
            Age
            <input
              name="age"
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className={boxClass(errors.age)}
              placeholder="Your age"
            />
            {errors.age && <span className="error">{errors.age}</span>}
          </label>
        </div>

        <label>
          Event
          <select name="event" value={eventName} onChange={(e) => setEventName(e.target.value)}>
            {/* LOOP: the dropdown is built from the shared events array */}
            {events.map((ev) => (
              <option key={ev.id} value={ev.name}>
                {ev.name} {seatsLabel(ev.seats)}
              </option>
            ))}
          </select>
          {errors.event && <span className="error">{errors.event}</span>}
        </label>

        <label>
          Number of tickets
          <input
            name="tickets"
            type="number"
            min="1"
            value={tickets}
            onChange={(e) => setTickets(e.target.value)}
            className={boxClass(errors.tickets)}
          />
          {errors.tickets && <span className="error">{errors.tickets}</span>}
        </label>

        <label className="checkbox-label">
          <input
            name="terms"
            type="checkbox"
            checked={terms}
            onChange={(e) => setTerms(e.target.checked)}
          />
          I have read the event rules and refund policy
        </label>
        {errors.terms && <span className="error">{errors.terms}</span>}

        <div className="form-actions">
          <button type="submit" className="btn-primary">Confirm registration</button>
          <button type="button" className="btn-secondary" onClick={clearForm}>Clear form</button>
        </div>
      </form>
      </section>

      <Footer />
    </div>
  );
}

// DECISION MAKING: what the dropdown writes next to each event name
function seatsLabel(seats) {
  if (seats <= 0) {
    return '(sold out)';
  }
  return '(' + seats + ' left)';
}

export default Register;
